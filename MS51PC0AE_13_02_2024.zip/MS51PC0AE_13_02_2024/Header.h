/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
#include "MS51_32K.H"
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
sbit SRDAT	  = P3^4;
sbit SRCLK	  = P3^0;
sbit SRPL	    = P1^7;
sbit PWR_SEL	= P2^5;
sbit LED_AM	  = P3^6;
sbit LED_ST	  = P3^7;
sbit SEL_AM	  = P1^4;
sbit EN0	    = P2^4;
sbit EN1	    = P2^3;
sbit EN2	    = P2^2;
sbit EN3	    = P2^1;
sbit EN4	    = P1^1;
sbit EN5	    = P1^0;
sbit EN6	    = P0^0;
sbit EN7	    = P0^1;
sbit MUX_C2	  = P3^5;
sbit MUX_C1	  = P3^1;
sbit MUX_C0	  = P3^2;
sbit MUX_EN	  = P1^2;
sbit MCU_TXD	= P0^6;
sbit MCU_RXD	= P0^7;
sbit GPIO1	  = P3^3;
sbit GPIO2	  = P0^3;
sbit GPIO3	  = P0^4;
sbit GPIO4	  = P0^5;
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
#define LEDAUTOSEL    0 
#define LEDEXTINTSEL  1 
#define ON            0
#define OFF           1
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void BoardInit(void);
void ConfigGpio(void);
void ConfigInt24MhzSysClk(void);
void UartInit(void);
void ControlLed(unsigned char,unsigned char);
void BlinkLeds(unsigned char);
void SwDelay(unsigned int,unsigned int);
void Defaults(void);
void ReadRotary(void);
void UsbMux(unsigned char);
void ReadAmSw(void);
void ReadEiSw(void);
void SndBrdStat(void);
void ExeUsbCmd(void);




