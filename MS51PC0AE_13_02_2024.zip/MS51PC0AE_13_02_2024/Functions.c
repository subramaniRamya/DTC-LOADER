/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
#include"Header.h"
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
extern unsigned char CmdFlag;
extern unsigned char UartData;
extern unsigned char ExtInSwData;
extern unsigned char AmSwData;
extern unsigned char RotarySwData;
extern unsigned char UsbMuxData;
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void SwDelay(unsigned int a,unsigned int b)
{
 unsigned int x = 0;
 unsigned int y = 0;
 for(x=0;x<=a;x++)
 for(y=0;y<=b;y++);
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void BlinkLeds(unsigned char BlinkCount)
{
 unsigned char i = 0;
 for(i=0;i<BlinkCount;i++)
 {
  ControlLed(LEDAUTOSEL,ON);
  ControlLed(LEDEXTINTSEL,ON);
  SwDelay(500,500);
  ControlLed(LEDAUTOSEL,OFF);
  ControlLed(LEDEXTINTSEL,OFF);
  SwDelay(500,500);
 }
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ControlLed(unsigned char LedType,unsigned char LedData)
{
 if(LedType == 0)LED_AM = LedData;
 else LED_ST =  LedData;
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ReadEiSw(void)
{
 if(PWR_SEL == 0){ExtInSwData = 'E';ControlLed(LEDEXTINTSEL,ON);}
 else {ExtInSwData = 'I';ControlLed(LEDEXTINTSEL,OFF);}
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ReadAmSw(void)
{
 if(SEL_AM == 0){AmSwData = 'A';ControlLed(LEDAUTOSEL,ON);}
 else {AmSwData = 'M';ControlLed(LEDAUTOSEL,OFF);}
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ReadRotary(void)
{
 unsigned char ShftData = 0;
 unsigned char i = 0;	
 SRCLK = 0;
 SRPL	 = 0;SwDelay(5,5);
 SRPL	 = 1;SwDelay(5,5);
 for(i=0;i<8;i++)
 {
	ShftData = ShftData >> 1;
	if(SRDAT == 1)ShftData=ShftData|0x80;
	SRCLK = 1;SwDelay(5,5); 
	SRCLK = 0;SwDelay(5,5);
 }
 switch(ShftData)
 {
  case 0xFE:RotarySwData = '1';break;
  case 0xFD:RotarySwData = '2';break;
  case 0xFB:RotarySwData = '3';break;
  case 0xF7:RotarySwData = '4';break;
  case 0xEF:RotarySwData = '5';break;
  case 0xDF:RotarySwData = '6';break;
  case 0xBF:RotarySwData = '7';break;
  case 0x7F:RotarySwData = '8';break;
  default  :RotarySwData = '0';break;
 }
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void UsbMux(unsigned char ControlData)
{
 if(ExtInSwData == 'I')
 {
  switch(ControlData)
  {
   case '1':UsbMuxData='1';EN7=1;EN6=1;EN5=1;EN4=1;EN3=1;EN2=1;EN1=1;EN0=0;SwDelay(100,100);MUX_EN=1;MUX_C2=0;MUX_C1=0;MUX_C0=0;break;
   case '2':UsbMuxData='2';EN7=1;EN6=1;EN5=1;EN4=1;EN3=1;EN2=1;EN1=0;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=0;MUX_C1=0;MUX_C0=1;break;
   case '3':UsbMuxData='3';EN7=1;EN6=1;EN5=1;EN4=1;EN3=1;EN2=0;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=0;MUX_C1=1;MUX_C0=0;break;
   case '4':UsbMuxData='4';EN7=1;EN6=1;EN5=1;EN4=1;EN3=0;EN2=1;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=0;MUX_C1=1;MUX_C0=1;break;
   case '5':UsbMuxData='5';EN7=1;EN6=1;EN5=1;EN4=0;EN3=1;EN2=1;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=1;MUX_C1=0;MUX_C0=0;break;
   case '6':UsbMuxData='6';EN7=1;EN6=1;EN5=0;EN4=1;EN3=1;EN2=1;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=1;MUX_C1=0;MUX_C0=1;break;
   case '7':UsbMuxData='7';EN7=1;EN6=0;EN5=1;EN4=1;EN3=1;EN2=1;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=1;MUX_C1=1;MUX_C0=0;break;
   case '8':UsbMuxData='8';EN7=0;EN6=1;EN5=1;EN4=1;EN3=1;EN2=1;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=1;MUX_C2=1;MUX_C1=1;MUX_C0=1;break;
   default :UsbMuxData='0';EN7=1;EN6=1;EN5=1;EN4=1;EN3=1;EN2=1;EN1=1;EN0=1;SwDelay(100,100);MUX_EN=0;MUX_C2=0;MUX_C1=0;MUX_C0=0;break;
  }
 }
 else
 {
	EN7=0;EN6=0;EN5=0;EN4=0;EN3=0;EN2=0;EN1=0;EN0=0;SwDelay(100,100);
  switch(ControlData)
  {
   case '1':UsbMuxData='1';MUX_EN=1;MUX_C2=0;MUX_C1=0;MUX_C0=0;break;
   case '2':UsbMuxData='2';MUX_EN=1;MUX_C2=0;MUX_C1=0;MUX_C0=1;break;
   case '3':UsbMuxData='3';MUX_EN=1;MUX_C2=0;MUX_C1=1;MUX_C0=0;break;
   case '4':UsbMuxData='4';MUX_EN=1;MUX_C2=0;MUX_C1=1;MUX_C0=1;break;
   case '5':UsbMuxData='5';MUX_EN=1;MUX_C2=1;MUX_C1=0;MUX_C0=0;break;
   case '6':UsbMuxData='6';MUX_EN=1;MUX_C2=1;MUX_C1=0;MUX_C0=1;break;
   case '7':UsbMuxData='7';MUX_EN=1;MUX_C2=1;MUX_C1=1;MUX_C0=0;break;
   case '8':UsbMuxData='8';MUX_EN=1;MUX_C2=1;MUX_C1=1;MUX_C0=1;break;
   default :UsbMuxData='0';MUX_EN=0;MUX_C2=0;MUX_C1=0;MUX_C0=0;break;
  }
 }
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ExeUsbCmd(void)
{
 switch(UartData)
 {
	case '0':UsbMux('0');break;
  case '1':UsbMux('1');break;
  case '2':UsbMux('2');break;
  case '3':UsbMux('3');break;
  case '4':UsbMux('4');break;
  case '5':UsbMux('5');break;
  case '6':UsbMux('6');break;
  case '7':UsbMux('7');break;
  case '8':UsbMux('8');break;
  default :break;
 }
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void SndBrdStat(void)
{
 SBUF = ExtInSwData;
 while(TI==0);TI=0;
 SBUF = AmSwData;
 while(TI==0);TI=0; 
 SBUF = RotarySwData;
 while(TI==0);TI=0;	
 SBUF = UsbMuxData;
 while(TI==0);TI=0;
	
 SBUF = 0x0D;
 while(TI==0);TI=0;	
 SBUF = 0x0A;
 while(TI==0);TI=0;
 CmdFlag = 0;
}
