/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
#include"Header.h"
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
extern unsigned char CmdFlag;
extern unsigned char UartData;
extern unsigned char ExtInSwData;
extern unsigned char AmSwData;
extern unsigned char RotarySwData;
extern unsigned char UsbMuxData;
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void BoardInit(void)
{
 ConfigGpio();
 ConfigInt24MhzSysClk();
 UartInit();
 IE |= 0x80;
 BlinkLeds(3);
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ConfigGpio(void)
{
 SRCLK   = 0;
 SRPL    = 1;
 LED_ST  = 1;
 LED_AM  = 1;
 EN0     = 1; 
 EN1     = 1;
 EN2     = 1;
 EN3     = 1;
 EN4     = 1;
 EN5     = 1;
 EN6     = 1;
 EN7     = 1;
 MUX_C2  = 0;
 MUX_C1  = 0;
 MUX_C0  = 0;
 MUX_EN  = 0;
 SFRS    = 0;
 P3M1   |= 0x10;
 P3M2   &= 0xEF;
 P1M1   |= 0x10;
 P1M2   &= 0xEF;	
 P0M1   |= 0x80;
 P0M2   &= 0x7F;
 P3M1   |= 0x08;
 P3M2   &= 0xF7;
 P0M1   |= 0x08;
 P0M2   &= 0xF7;	
 P0M1   |= 0x10;
 P0M2   &= 0xEF;
 P0M1   |= 0x20;
 P0M2   &= 0xDF;
 P3M1   &= 0xFE;
 P3M2   |= 0x01;
 P1M1   &= 0x7F;
 P1M2   |= 0x80;
 P3M1   &= 0xBF;
 P3M2   |= 0x40;
 P3M1   &= 0x7F;
 P3M2   |= 0x80;
 P1M1   &= 0xFD;
 P1M2   |= 0x02;
 P1M1   &= 0xFE;
 P1M2   |= 0x01;
 P0M1   &= 0xFE;
 P0M2   |= 0x01;
 P0M1   &= 0xFD;
 P0M2   |= 0x02;
 P3M1   &= 0xDF;
 P3M2   |= 0x20;
 P3M1   &= 0xFD;
 P3M2   |= 0x02;
 P3M1   &= 0xFB;
 P3M2   |= 0x04;
 P1M1   &= 0xFB;
 P1M2   |= 0x04;
 P0M1   &= 0xBF;
 P0M2   |= 0x40;
 SFRS    = 2;
 P3UP   |= 0x10;	
 P2M1   |= 0x20;
 P2M2   &= 0xDF;
 P2UP   |= 0x20;	
 P1UP   |= 0x10;	
 P0UP   |= 0x80;	
 P3UP   |= 0x08;	
 P0UP   |= 0x08;	
 P0UP   |= 0x10;	
 P0UP   |= 0x20;	
 P2M1   &= 0xEF;
 P2M2   |= 0x10;
 P2M1   &= 0xF7;
 P2M2   |= 0x08;
 P2M1   &= 0xFB;
 P2M2   |= 0x04;
 P2M1   &= 0xFD;
 P2M2   |= 0x02;
 SFRS    = 0;
}
/////////////////////////////////////////////////////////////////////
//
/////////////////////////////////////////////////////////////////////
void ConfigInt24MhzSysClk(void)
{
 unsigned char data Temp0,Temp1;
 EA       = 0;	
 SFRS     = 0x00;
 IAPAL    = 0x38;
 TA       = 0xAA;
 TA       = 0x55;
 CHPCON   = CHPCON | 0x01;
 IAPAH    = 0x00;
 IAPCN    = 0x04;
 TA       = 0xAA;
 TA       = 0x55;
 IAPTRG   = IAPTRG | 0x01;
 Temp0    = IAPFD;
 IAPAL    = IAPAL+1;
 TA       = 0xAA;
 TA       = 0x55;
 IAPTRG   = IAPTRG | 0x01;
 Temp1    = IAPFD;
 TA       = 0xAA;
 TA       = 0x55;
 RCTRIM0  = Temp0;
 TA       = 0xAA;
 TA       = 0x55;
 RCTRIM1  = Temp1;
 TA       = 0xAA;
 TA       = 0x55;
 CHPCON   = CHPCON& 0xFE;
 PCON     = PCON  & 0xEF;
}
/////////////////////////////////////////////////////////////////////
//BaudRate = 115200
/////////////////////////////////////////////////////////////////////
void UartInit(void)
{
 SFRS   = 0x00;
 SCON   = 0x50;          
 PCON  |= 0x80;         
 T3CON &= 0xF8;         
 T3CON |= 0x20;         
 RH3    = 0xFF; 
 RL3    = 0x64; 
 T3CON |= 0x08;          
 IE    |= 0x10;
 TI     = 0;
}
